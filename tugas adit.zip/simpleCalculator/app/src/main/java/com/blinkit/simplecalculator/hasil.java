package com.blinkit.simplecalculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import java.text.DecimalFormat;

public class hasil extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hasil);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Hasil");

        TextView text = findViewById(R.id.hasil);

        hasil_parcel total = getIntent().getParcelableExtra("hasil");

        double hasil = total.hasil();

        text.setText(new DecimalFormat("##.##").format(hasil));
    }
}
