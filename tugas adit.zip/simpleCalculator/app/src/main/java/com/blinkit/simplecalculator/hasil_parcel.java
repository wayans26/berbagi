package com.blinkit.simplecalculator;

import android.os.Parcel;
import android.os.Parcelable;

public class hasil_parcel implements Parcelable {
    private double bil1, bil2;
    private String operator;

    public double hasil(){
        double hasil = 0;
        if (operator.equals("tambah")){
            hasil = bil1 + bil2;
        }

        else if (operator.equals("kurang")){
            hasil = bil1 - bil2;
        }
        else if (operator.equals("kali")){
            hasil = bil1 * bil2;
        }
        else if (operator.equals("bagi")){
            if (bil1 < bil2){
                hasil = bil2 / bil1;
            }
            else {
                hasil = bil1 / bil2;
            }
        }
        return hasil;
    }

    public double getBil1() {
        return bil1;
    }

    public void setBil1(double bil1) {
        this.bil1 = bil1;
    }

    public double getBil2() {
        return bil2;
    }

    public void setBil2(double bil2) {
        this.bil2 = bil2;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeDouble(this.bil1);
        dest.writeDouble(this.bil2);
        dest.writeString(this.operator);
    }

    public hasil_parcel() {
    }

    protected hasil_parcel(Parcel in) {
        this.bil1 = in.readDouble();
        this.bil2 = in.readDouble();
        this.operator = in.readString();
    }

    public static final Creator<hasil_parcel> CREATOR = new Creator<hasil_parcel>() {
        @Override
        public hasil_parcel createFromParcel(Parcel source) {
            return new hasil_parcel(source);
        }

        @Override
        public hasil_parcel[] newArray(int size) {
            return new hasil_parcel[size];
        }
    };
}
