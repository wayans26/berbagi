package com.blinkit.simplecalculator;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText bil1, bil2;
    RadioGroup rdi_group;
    RadioButton rdOperator;
    hasil_parcel total = new hasil_parcel();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bil1 = (EditText) findViewById(R.id.bil1);
        bil2 = (EditText) findViewById(R.id.bil2);
        rdi_group = (RadioGroup) findViewById(R.id.radio_button_group);
        rdi_group.setVisibility(View.GONE);

        bil1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                checkInput();
            }
        });

        bil2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                checkInput();
            }
        });

        rdi_group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                int pilih = rdi_group.getCheckedRadioButtonId();
                rdOperator = findViewById(pilih);

                double bil_1 = Double.parseDouble(bil1.getText().toString());
                double bil_2 = Double.parseDouble(bil2.getText().toString());
                operasi(bil_1, bil_2);
            }
        });


    }

    private void checkInput(){
        if (bil1.length() > 0 && bil2.length() > 0){

            rdi_group.setVisibility(View.VISIBLE);
        }
        else{
            rdi_group.setVisibility(View.GONE);
        }
    }

    private void operasi(double bil1, double bil2){
        double hasil = 0;
        if (rdOperator.getText().equals("Tambah")){
            total.setOperator("tambah");
            //hasil = bil1 + bil2;
        }
        else  if (rdOperator.getText().equals("Kurang")){
            total.setOperator("kurang");
            //hasil = bil1 - bil2;
        }
        else  if (rdOperator.getText().equals("Kali")){
            total.setOperator("kali");
            //hasil = bil1 * bil2;
        }
        else  if (rdOperator.getText().equals("Bagi")){
            total.setOperator("bagi");
            //hasil = 0;
            if (bil1 < bil2){
                //hasil = bil2 / bil1;
            }
            else {
                //hasil = bil1 / bil2;
            }
        }

        total.setBil1(bil1);
        total.setBil2(bil2);
        Intent i = new Intent(getApplicationContext(), com.blinkit.simplecalculator.hasil.class);
        i.putExtra("hasil", total);
        startActivity(i);

    }
}
